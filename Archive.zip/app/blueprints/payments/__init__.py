"""Payments blueprint."""
from flask import Blueprint

payments_bp = Blueprint('payments', __name__, template_folder='../../templates')

# Import routes after blueprint is created
from app.blueprints.payments import routes  # noqa: F401, E402
